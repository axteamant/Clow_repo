package it.ant.components;


import oracle.jdbc.pool.OracleDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.sql.DataSource;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import java.sql.SQLException;
//@Configuration
//@Validated
//@ConfigurationProperties("spring.secondDatasource")
public class OracleConfiguration {
	
//	@NotNull
//    private String username;
//    @NotNull
//    private String password;
//    @NotNull
//    private String url;
//    public void setUsername(String username) {
//        this.username = username;
//    }
//    public void setPassword(String password) {
//        this.password = password;
//    }
//    public void setUrl(String url) {
//        this.url = url;
//    }
//    @Bean(name = "Orasql")
//  
//    DataSource OraDataSource() throws SQLException {
//        OracleDataSource dataSource = new OracleDataSource();
//        dataSource.setUser(username);
//        dataSource.setPassword(password);
//        dataSource.setURL(url);
//        dataSource.setImplicitCachingEnabled(true);
//        dataSource.setFastConnectionFailoverEnabled(true);
//        return dataSource;
//    }
}